﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoEF.Data.Entities
{
    public class KoInOrderItem58659
    {
        public int Id { get; set; }
        public KoInProduct58659 Product{ get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public KoInOrder58659 Order { get; set; }
    }
}
