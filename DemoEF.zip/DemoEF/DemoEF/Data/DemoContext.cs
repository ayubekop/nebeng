﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoEF.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace DemoEF.Data
{
    public class DemoContext : DbContext
    {
        public DemoContext(DbContextOptions<DemoContext> options): base(options)
        {

        }

        public DbSet<KoInProduct58659> KoInProduct58659 { get; set; }
        public DbSet<KoInOrder58659> KoInOrder58659 { get; set; }
    }
}
