﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DemoEF.Data;
using DemoEF.Data.Entities;

namespace DemoEF.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class KoInProduct58659Controller : ControllerBase
    {
        private readonly DemoContext _context;

        public KoInProduct58659Controller(DemoContext context)
        {
            _context = context;
        }

        // GET: api/KoInProduct58659
        [HttpGet]
        public IEnumerable<KoInProduct58659> GetKoInProduct58659()
        {
            return _context.KoInProduct58659;
        }

        // GET: api/KoInProduct58659/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetKoInProduct58659([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var koInProduct58659 = await _context.KoInProduct58659.FindAsync(id);

            if (koInProduct58659 == null)
            {
                return NotFound();
            }

            return Ok(koInProduct58659);
        }

        // PUT: api/KoInProduct58659/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutKoInProduct58659([FromRoute] int id, [FromBody] KoInProduct58659 koInProduct58659)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != koInProduct58659.Id)
            {
                return BadRequest();
            }

            _context.Entry(koInProduct58659).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!KoInProduct58659Exists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/KoInProduct58659
        [HttpPost]
        public async Task<IActionResult> PostKoInProduct58659([FromBody] KoInProduct58659 koInProduct58659)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.KoInProduct58659.Add(koInProduct58659);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetKoInProduct58659", new { id = koInProduct58659.Id }, koInProduct58659);
        }

        // DELETE: api/KoInProduct58659/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteKoInProduct58659([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var koInProduct58659 = await _context.KoInProduct58659.FindAsync(id);
            if (koInProduct58659 == null)
            {
                return NotFound();
            }

            _context.KoInProduct58659.Remove(koInProduct58659);
            await _context.SaveChangesAsync();

            return Ok(koInProduct58659);
        }

        private bool KoInProduct58659Exists(int id)
        {
            return _context.KoInProduct58659.Any(e => e.Id == id);
        }
    }
}